//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by soundrobber.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDM_DEVCAPS                     0x0020
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_SOUNDROBBER_DIALOG          102
#define IDS_DEVCAPS                     102
#define IDS_TITLE                       103
#define IDR_MAINFRAME                   128
#define IDD_DEVCAPS_DIALOG              130
#define IDC_BUTTON_OPEN                 1000
#define IDC_BUTTON_PLAY                 1001
#define IDC_BUTTON_STOP                 1002
#define IDC_BUTTON_WAVE                 1003
#define IDC_EDIT_END                    1004
#define IDC_EDIT_START                  1005
#define IDC_EDIT_SPEED                  1006
#define IDC_SPIN_SPEED                  1010
#define IDC_CHECK_MONO                  1011
#define IDC_CHECK_STEREO                1012
#define IDC_CHECK_REVERSE               1013
#define IDC_DCAPS                       1018
#define IDC_COMBO_DEVS                  1019
#define IDC_CHECK_16BITS                1020
#define IDC_CHECK_8BITS                 1021
#define IDC_POSITION                    1025
#define IDC_GET_START                   1029
#define IDC_GET_END                     1030
#define IDC_SCROLL_VOLUME               1031
#define IDC_CHECK_XOR                   1034
#define IDC_EDIT_XOR                    1036
#define IDC_CHECK_ADD                   1037
#define IDC_EDIT_ADD                    1038
#define IDC_CHECK_MAPPER                1041
#define IDC_PICTURE                     1042
#define IDC_SLIDER_START                1044
#define IDC_SLIDER_END                  1045

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        140
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1045
#define _APS_NEXT_SYMED_VALUE           102
#endif
#endif
